package fr.improve.struts.taglib.layout.crumb;

public interface Crumb {	
	public String getTarget();
	public String getKey();
	public String getLink();
	public String getBundle();
}
