package fr.improve.struts.taglib.layout.sort;

import java.text.Collator;

/**
 * Interface for sorting rules.
 * 
 * @author JN RIBETTE 
 */
public interface SortRules {
	public Collator getRules();
}
