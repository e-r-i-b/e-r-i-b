/*
 * Created on 18 f�vr. 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package fr.improve.struts.taglib.layout.collection.header;

/**
 * @author dev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface MultiLevelTitleHandler {
	public Object addCollectionTitle(CollectionItemEvent in_event);
}
