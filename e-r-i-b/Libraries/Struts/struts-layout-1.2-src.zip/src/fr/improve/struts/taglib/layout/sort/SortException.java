package fr.improve.struts.taglib.layout.sort;

/**
 * Insert the type's description here.
 * Creation date: (27/10/2001 15:37:30)
 * @author: Jean-No�l Ribette
 */
public class SortException extends javax.servlet.ServletException {
	public SortException() {
		super();
	}
	public SortException(String in_message) {
		super(in_message);
	}
	public SortException(Throwable t) {
		super(t);
	}
}
