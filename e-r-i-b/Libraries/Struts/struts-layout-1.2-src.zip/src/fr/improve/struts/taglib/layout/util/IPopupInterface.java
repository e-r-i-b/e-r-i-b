package fr.improve.struts.taglib.layout.util;

public interface IPopupInterface extends PanelInterface {

}
