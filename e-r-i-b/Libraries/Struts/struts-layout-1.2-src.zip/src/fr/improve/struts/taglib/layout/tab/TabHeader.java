package fr.improve.struts.taglib.layout.tab;

/**
 * @author jnribette
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class TabHeader {
	public String title;
	public String width;
	public String styleClass;
	public String href;
	public String reqCode;
	
	public String titleKey;	
}
