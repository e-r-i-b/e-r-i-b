/*
 * (c) Copyright 2001 MyCorporation.
 * All Rights Reserved.
 */
package fr.improve.struts.taglib.layout.formatter;
/**
 * @version 	1.0
 * @author
 */
public class FormatException extends Exception {
	public FormatException(String in_message) {
		super(in_message);	
	}
}
