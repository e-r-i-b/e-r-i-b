package fr.improve.struts.taglib.layout;


/**
 * @author: Jean-No�l Ribette
 */
public class SubmitTag extends ActionTag {
	public SubmitTag() {
		tag = new org.apache.struts.taglib.html.SubmitTag();
	}
}
