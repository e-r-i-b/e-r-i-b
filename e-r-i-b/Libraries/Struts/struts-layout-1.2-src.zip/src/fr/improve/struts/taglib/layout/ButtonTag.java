package fr.improve.struts.taglib.layout;

/**
 * @author jnribette
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class ButtonTag extends ActionTag {
	public ButtonTag() {
		tag = new org.apache.struts.taglib.html.ButtonTag();
	}
}
