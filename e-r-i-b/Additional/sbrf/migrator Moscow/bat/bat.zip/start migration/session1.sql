set serveroutput on;
begin
	migratormoscow.migrateclients('0', 99, 1);
	dbms_output.put_line('Migration process is finished.');
end;
/