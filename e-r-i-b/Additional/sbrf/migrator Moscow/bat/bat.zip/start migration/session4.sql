set serveroutput on;
begin
	migratormoscow.migrateclients('0', 99, 4);
	dbms_output.put_line('Migration process is finished.');
end;
/